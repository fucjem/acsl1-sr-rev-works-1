//nn9
//Owen Watts

#include <iostream>
#include <fstream>
//#include <string>
//#include <stdlib.h>

using namespace std;

int main()
{
  string input="no";
  ifstream myfile;
  myfile.open("sr.txt",ifstream::in);
  getline (myfile, input);
  //cout<<input<<endl;

  //get end number of input
  int wspace=input.find(' ');
  string pergroup=input.substr(wspace+1);
  char pergroupchar=pergroup.back();
  input.erase(wspace);
  //DONE

  int pgAsI=stoi(pergroup);
  //cout<<pgAsI<<endl;

  int remainder=input.length()%pgAsI;
  while (remainder>0)
  {
    //cout<<"remainder: "<<remainder<<endl;

    //ARRAGNGE ZEROES
    input.insert(input.end(),'0');
    //cout<<input<<endl;
    remainder=input.length()%pgAsI;
  }
  string splitup[(input.length()/2)];
  
  int fromhere=0;
  int tohere=pgAsI;
  for(int i=0; i<(input.length()/2)-1; i++)
  {
    //cout<<addtofromhere<<"<atfh "<<addtotohere<<"<atth "<<fromhere<<"<fh "<<tohere<<"<th "<<pgAsI<<"<pgAsI "<<endl;
    //cout<<fromhere<<" "<<tohere<<endl;
    splitup[i]=input.substr(fromhere,tohere);
    fromhere=fromhere+3;
    //tohere=tohere+3;
  }

  /*
  for(int i=0; i<(input.length()/2)-1; i++)
  {
    cout<<splitup[i]<<endl;
    //cout<<" "<<i<<" "<<endl;
  }
  */

  int splitupAsI[input.length()/2-1];
  int finalnumber=0;
  for(int i=0; i<(input.length()/2)-1; i++)
  {
    splitupAsI[i]=stoi(splitup[i]);
    //cout<<splitupAsI[i]<<" ";
    finalnumber=finalnumber+splitupAsI[i];
  } 
  
  cout<<"final number: "<<finalnumber<<endl;
}
